﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;


namespace H5UploadDemo
{
    public partial class uploadimage_do : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpPostedFile file = Request.Files["Filedata"];//这个参数名，在Huploadify.js中可以自由设置，原来是file
            string uploadPath = HttpContext.Current.Server.MapPath("Uploads" + "\\");
            string new_name = Request["new_name"];//当前图片的重命名

            if (file != null)
            {
                if (!Directory.Exists(uploadPath))
                {
                    Directory.CreateDirectory(uploadPath);
                }
                string fileExt = System.IO.Path.GetExtension(file.FileName);
                file.SaveAs(uploadPath + new_name + fileExt);

                //等比例缩放，保留原图，创建新图
                int width = int.Parse(Request.QueryString["w"]);
                string originalImagePath = uploadPath + new_name + fileExt;
                string thumbnailPath = uploadPath + new_name + "_" + fileExt;
                WhyPicture.MakeThumbnail(originalImagePath, thumbnailPath, width, 0, "W");
                //下面这句代码缺少的话，上传成功后上传队列的显示不会自动消失
                Response.Write("1");
            }
            else
            {
                Response.Write("0");
            }
        }
    }
}